####################### Hexcarto Demo ###############################
######################################################################
############# Created: February 10, 2020 ############################
library("devtools")
library("roxygen2")
install_github("jcuriel-unc/hexcarto") ###enter pkg installations here; there are like 66 options, which is probably what might break R 

#### now, load a shp file, in this case MI 
# setwd("C:/Users/johna/Dropbox (Curiel Analytx)/Curiel Analytx Team Folder/overlap_pkg/hexocart/demo")
###set working directory here 
#dir_path <- "C:/Users/johna/Dropbox (Curiel Analytx)/Curiel Analytx Team Folder/overlap_pkg/hexocart/demo" 
dir_path <- " " #path to demo directory 
setwd("C:/Users/johna/Dropbox (Curiel Analytx)/Curiel Analytx Team Folder/overlap_pkg/hexocart/demo")
unzip("mi_shp_party.zip")
dir_path2 <- paste(dir_path, sep="/", "mi_shp_party")

###reading in the shp file 
mi_shp <- readOGR(dir_path2, "mi_reg_party") # shpfile of MI with congressional party vote share by county 

###now will create a hexagrid of the plot, with color 
mi_shp$color <- "blue"
mi_shp$color[mi_shp$gop_vote_s > 50] <- "red" # this makes the color such that any counties with a GOP 2 party vote share greater than 50 is red 
mi_hex <- makeTilegram2(mi_shp) #literally just feed it the spatial object
plot(mi_hex, col=mi_hex$color, title="Michigan 2 Party Vote Share by County, 2018") 
legend("bottomleft", fill=c("blue","red"), legend = c("GOP vote < 50%", "GOP vote > 50%"), bty="n" )
## all that the user needs to do is add in the color command. Can also easily add legend and such 

###now, create a cartogram by county 
### produces a map where the cartogram weights are apportioned by quantile 
hexcarto2b(mi_shp, pop_field = "VAP2010", colval = "color", choro_field = "gop_vote_s", label_field = "NAME", quant_carto_breaks = TRUE )

##now the above, but without labels 
hexcarto2b(mi_shp, pop_field = "VAP2010", colval = "color", choro_field = "gop_vote_s", quant_carto_breaks = TRUE )

### now a cartogram with jenks breaks 
hexcarto2b(mi_shp, pop_field = "VAP2010", jenks=T, choro_field = "gop_vote_s", label_field = "NAME", quant_carto_breaks = TRUE )

###now let's mess things up by setting quant_carto_breaks = F on a very non normal pop dist. 
hexcarto2b(mi_shp, pop_field = "VAP2010", choro_field = "gop_vote_s", label_field = "NAME", quant_carto_breaks = FALSE )
legend("bottomleft", fill=c("blue","red"), legend = c("GOP vote < 50%", "GOP vote > 50%"), bty="n" ) # that's right, can easily add legend 
# and such and later export this. 



